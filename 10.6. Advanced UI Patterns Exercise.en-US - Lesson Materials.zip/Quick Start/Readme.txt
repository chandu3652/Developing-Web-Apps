The OSMDB.oap file in this Quickstart directory is an OutSystems Application Package (.oap) file.

It contains the work completed in previous exercises that is required as the starting point for this exercise.  You can open it in Service Studio by double clicking on it or selecting Open Files... from the Environment menu.

It may be missing some of the data changed through the user interface in previous exercises as it only has the code from the modules and the originally bootstrapped data. 